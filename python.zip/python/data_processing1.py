import json
import matplotlib.pyplot as plt
import folium
import argparse
from collections import defaultdict
from tabulate import tabulate
from colorama import Fore, Style

# Argument parser to allow dynamic file input
parser = argparse.ArgumentParser(description="Process location data")
parser.add_argument("--locations", type=str, required=True, help="Path to locations JSON file")
parser.add_argument("--metadata", type=str, required=True, help="Path to metadata JSON file")
args = parser.parse_args()

# Load JSON Data from files
with open(args.locations) as f:
    locations_json = json.load(f)
with open(args.metadata) as f:
    metadata_json = json.load(f)

# Convert metadata to a dictionary for quick lookup
metadata_dict = {entry['id']: entry for entry in metadata_json}

# Merge data and check for incomplete entries
merged_data = []
incomplete_data = []
for location in locations_json:
    loc_id = location['id']
    if loc_id in metadata_dict:
        merged_data.append({**location, **metadata_dict[loc_id]})
    else:
        incomplete_data.append(location)  # Locations without metadata

# Count locations per type
type_counts = defaultdict(int)
average_ratings = defaultdict(list)
max_reviews = {"id": None, "reviews": 0}

for entry in merged_data:
    loc_type = entry['type']
    type_counts[loc_type] += 1
    average_ratings[loc_type].append(entry['rating'])
    
    # Check for max reviews
    if entry['reviews'] > max_reviews['reviews']:
        max_reviews = {"id": entry['id'], "reviews": entry['reviews']}

# Calculate average rating per type
average_ratings = {t: sum(ratings)/len(ratings) for t, ratings in average_ratings.items()}

# Print tabulated results with colors
print(Fore.CYAN + "\n📊 Summary Report" + Style.RESET_ALL)
table = [[t, type_counts[t], round(average_ratings[t], 2)] for t in type_counts]
print(tabulate(table, headers=["Type", "Count", "Avg Rating"], tablefmt="grid"))

print(Fore.YELLOW + "\n🏆 Most Reviewed Location:" + Style.RESET_ALL, max_reviews)
print(Fore.RED + "🛠 Locations with Incomplete Data:" + Style.RESET_ALL, incomplete_data)

# Save results to JSON file
results = {
    "location_counts": dict(type_counts),
    "average_ratings": average_ratings,
    "most_reviewed_location": max_reviews,
    "incomplete_data": incomplete_data
}

with open("results.json", "w") as f:
    json.dump(results, f, indent=4)

print("Results saved to results.json ✅")

# Plot location counts
plt.figure(figsize=(8, 4))
plt.bar(type_counts.keys(), type_counts.values(), color=['blue', 'green', 'red'])
plt.xlabel("Location Type")
plt.ylabel("Count")
plt.title("Number of Locations per Type")
plt.show()

# Generate interactive map
map_obj = folium.Map(location=[20, 0], zoom_start=2)
for entry in merged_data:
    folium.Marker(
        location=[entry["latitude"], entry["longitude"]],
        popup=f"{entry['type'].title()} - Rating: {entry['rating']}",
        icon=folium.Icon(color="blue" if entry["type"] == "restaurant" else "green")
    ).add_to(map_obj)

map_obj.save("locations_map.html")
print("🌍 Map saved as locations_map.html. Open it in a browser!")

# Create a simple Flask API to serve results
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/results", methods=["GET"])
def get_results():
    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True)
